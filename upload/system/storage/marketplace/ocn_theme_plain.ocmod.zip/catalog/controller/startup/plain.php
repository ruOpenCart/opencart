<?php
namespace Opencart\Catalog\Controller\Extension\OcnThemePlain\Startup;
class Plain extends \Opencart\System\Engine\Controller {
	public function index(): void {
		if ($this->config->get('config_theme') == 'plain' && $this->config->get('theme_plain_status')) {
			$this->event->register('view/*/before', new \Opencart\System\Engine\Action('extension/ocn_theme_plain/startup/plain.event'));
		}
	}

	public function event(string &$route, array &$args, mixed &$output): void {
		$override = [
			'common/header',
			'common/cart',
			'product/thumb',
			'product/product',
			'checkout/cart_list',
		];

		if (in_array($route, $override, true)) {
			$route = 'extension/ocn_theme_plain/' . $route;
		}
	}
}

<?php
// Heading
$_['heading_title']    = 'OCN Plain';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки шаблона OCN Plain сохранены.';
$_['text_edit']        = 'Редактирование OCN Plain';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Недостаточно прав для изменения шаблона OCN Plain.';

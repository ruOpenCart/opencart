<?php
// Heading
$_['heading_title']    = 'OCN Plain';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified the OCN Plain theme!';
$_['text_edit']        = 'Edit OCN Plain';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the OCN Plain theme!';

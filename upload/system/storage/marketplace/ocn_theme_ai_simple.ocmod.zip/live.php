<?php
header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

clearstatcache(true);

$root = __DIR__;
$max = 0;
$allowed = ['twig' => true, 'css' => true, 'js' => true];

try {
	$directory = new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS);
	$files = new RecursiveIteratorIterator($directory);

	foreach ($files as $file) {
		if (!$file->isFile()) {
			continue;
		}

		$extension = strtolower($file->getExtension());

		if (!isset($allowed[$extension])) {
			continue;
		}

		$mtime = $file->getMTime();

		if ($mtime > $max) {
			$max = $mtime;
		}
	}
} catch (Throwable $e) {
	$max = 0;
}

echo (string)$max;

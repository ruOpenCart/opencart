<?php
// Heading
$_['heading_title']    = 'AI Simple';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки шаблона AI Simple сохранены.';
$_['text_edit']        = 'Редактирование AI Simple';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Недостаточно прав для изменения шаблона AI Simple.';

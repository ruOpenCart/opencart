<?php
namespace Opencart\Catalog\Controller\Extension\OcnThemeAiSimple\Startup;
class Plain extends \Opencart\System\Engine\Controller {
	public function index(): void {
		if ($this->config->get('config_theme') == 'ai_simple' && $this->config->get('theme_ai_simple_status')) {
			$this->event->register('view/*/before', new \Opencart\System\Engine\Action('extension/ocn_theme_ai_simple/startup/plain.event'));
			$this->event->register('controller/common/currency/save/before', new \Opencart\System\Engine\Action('extension/ocn_theme_ai_simple/startup/plain.currencySaveBefore'));
			$this->event->register('controller/common/currency/save/after', new \Opencart\System\Engine\Action('extension/ocn_theme_ai_simple/startup/plain.currencySaveAfter'));
		}
	}

	public function currencySaveBefore(string &$route, array &$args): void {
		$redirect = $this->request->post['redirect'] ?? '';

		if (!is_string($redirect) || $redirect === '') {
			return;
		}

		$this->request->post['redirect'] = $this->storeUrl(html_entity_decode($redirect, ENT_QUOTES, 'UTF-8'));
	}

	public function currencySaveAfter(string &$route, array &$args, mixed &$output): void {
		$requestedWith = $this->request->server['HTTP_X_REQUESTED_WITH'] ?? '';

		if (is_string($requestedWith) && strcasecmp($requestedWith, 'XMLHttpRequest') === 0) {
			return;
		}

		$json = json_decode($this->response->getOutput(), true);

		if (!is_array($json) || empty($json['redirect']) || !is_string($json['redirect'])) {
			return;
		}

		$this->response->redirect($json['redirect']);
	}

	public function event(string &$route, array &$args, mixed &$output): void {
		if ($this->isStoreFrame($route)) {
			$origin = $this->viteOrigin();
			$dev = $origin !== '';
			$versions = $this->libraryVersions();
			$combineValue = $this->config->get('theme_ai_simple_combine');
			$combine = (int)(is_scalar($combineValue) ? $combineValue : 0) === 1;
			$base = 'extension/ocn_theme_ai_simple/catalog/view/';

			$args['vite_dev'] = $dev;
			$args['vite_origin'] = $origin;
			$args['combine'] = $combine;

			if ($dev) {
				$args['css_bootstrap'] = $this->versioned($origin . '/node_modules/bootstrap/dist/css/bootstrap.min.css', $versions['bootstrap']);
				$args['css_icons'] = $this->versioned($origin . '/node_modules/@fortawesome/fontawesome-free/css/all.min.css', $versions['fontawesome']);
				$args['css_theme'] = $this->versioned($origin . '/src/main.css', $this->devVersion('css', 'catalog/view/stylesheet/theme.css'));
				$args['js_bootstrap'] = $this->versioned($origin . '/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js', $versions['bootstrap']);
				$args['js_theme'] = $this->versioned($origin . '/src/main.js', $this->devVersion('js', 'catalog/view/javascript/theme.js'));
				$args['css_photoswipe'] = $this->versioned($origin . '/node_modules/photoswipe/dist/photoswipe.css', $versions['photoswipe']);
				$args['js_photoswipe'] = $this->versioned($origin . '/node_modules/photoswipe/dist/umd/photoswipe.umd.min.js', $versions['photoswipe']);
				$args['js_photoswipe_lightbox'] = $this->versioned($origin . '/node_modules/photoswipe/dist/umd/photoswipe-lightbox.umd.min.js', $versions['photoswipe']);
			} else {
				$args['css_bootstrap'] = $this->versioned($base . 'stylesheet/bootstrap.min.css', $versions['bootstrap']);
				$args['css_icons'] = $this->versioned($base . 'stylesheet/fontawesome.min.css', $versions['fontawesome']);
				$args['css_theme'] = $this->versioned($base . 'stylesheet/theme.css', $this->fileVersion('catalog/view/stylesheet/theme.css'));
				$args['js_bootstrap'] = $this->versioned($base . 'javascript/bootstrap.bundle.min.js', $versions['bootstrap']);
				$args['js_theme'] = $this->versioned($base . 'javascript/theme.js', $this->fileVersion('catalog/view/javascript/theme.js'));
				$args['css_photoswipe'] = $this->versioned($base . 'stylesheet/photoswipe.css', $versions['photoswipe']);
				$args['js_photoswipe'] = $this->versioned($base . 'javascript/photoswipe.umd.min.js', $versions['photoswipe']);
				$args['js_photoswipe_lightbox'] = $this->versioned($base . 'javascript/photoswipe-lightbox.umd.min.js', $versions['photoswipe']);
			}

			$args['css_combined'] = $this->versioned($base . 'stylesheet/combined.css', $this->fileVersion('catalog/view/stylesheet/combined.css'));
			$args['js_combined'] = $this->versioned($base . 'javascript/combined.js', $this->fileVersion('catalog/view/javascript/combined.js'));
			$this->dropDocumentLibraries($args);
		}

		if (str_starts_with($route, 'extension/')) {
			if (!str_starts_with($route, 'extension/ocn_theme_ai_simple/')) {
				$parts = explode('/', $route);

				if (count($parts) >= 3) {
					$relative = implode('/', array_slice($parts, 2));
					$override = DIR_EXTENSION . 'ocn_theme_ai_simple/catalog/view/template/' . $relative . '.twig';

					if (is_file($override)) {
						$route = 'extension/ocn_theme_ai_simple/' . $relative;
					}
				}
			}

			return;
		}

		$file = DIR_EXTENSION . 'ocn_theme_ai_simple/catalog/view/template/' . $route . '.twig';

		if (is_file($file)) {
			$route = 'extension/ocn_theme_ai_simple/' . $route;
		}
	}

	private function dropDocumentLibraries(array &$args): void {
		foreach (['styles', 'scripts'] as $key) {
			if (!isset($args[$key]) || !is_array($args[$key])) {
				continue;
			}

			$kept = [];

			foreach ($args[$key] as $item) {
				$href = '';

				if (is_array($item)) {
					$href = (string)($item['href'] ?? '');
				} elseif (is_string($item)) {
					$href = $item;
				}

				$href = strtolower($href);

				if (str_contains($href, 'magnific') || str_contains($href, 'jquery') || str_contains($href, 'common.js')) {
					continue;
				}

				$kept[] = $item;
			}

			$args[$key] = $kept;
		}
	}

	private function isStoreFrame(string $route): bool {
		return $route === 'common/header'
			|| $route === 'common/footer'
			|| $route === 'extension/ocn_theme_ai_simple/common/header'
			|| $route === 'extension/ocn_theme_ai_simple/common/footer';
	}

	private function viteOrigin(): string {
		$file = DIR_EXTENSION . 'ocn_theme_ai_simple/hot';

		if (!is_file($file)) {
			return '';
		}

		$raw = file_get_contents($file);

		if (!is_string($raw)) {
			return '';
		}

		$origin = trim($raw);

		if (preg_match('#\Ahttps?://[A-Za-z0-9.\-]+:[0-9]{2,5}\z#', $origin) !== 1) {
			return '';
		}

		return $origin;
	}

	private function storeUrl(string $url): string {
		$origin = $this->viteOrigin();
		$store = (string)$this->config->get('config_url');

		if ($origin === '' || $store === '' || !str_starts_with($url, $origin)) {
			return $url;
		}

		$rest = substr($url, strlen($origin));

		if ($rest !== '' && !str_starts_with($rest, '/') && !str_starts_with($rest, '?') && !str_starts_with($rest, '#')) {
			return $url;
		}

		$store = rtrim($store, '/');

		if ($rest === '' || str_starts_with($rest, '?') || str_starts_with($rest, '#')) {
			return $store . '/' . $rest;
		}

		return $store . $rest;
	}

	private function libraryVersions(): array {
		$data = $this->readJson('assets.json');

		return [
			'bootstrap' => $this->versionText($data['bootstrap'] ?? ''),
			'fontawesome' => $this->versionText($data['fontawesome'] ?? ''),
			'photoswipe' => $this->versionText($data['photoswipe'] ?? ''),
		];
	}

	private function devVersion(string $key, string $relative): string {
		$data = $this->readJson('dev.json');
		$version = $this->versionText($data[$key] ?? '');

		if ($version !== '0') {
			return $version;
		}

		return $this->fileVersion($relative);
	}

	private function fileVersion(string $relative): string {
		$path = DIR_EXTENSION . 'ocn_theme_ai_simple/' . $relative;

		if (!is_file($path)) {
			return '0';
		}

		$mtime = filemtime($path);

		return $mtime === false ? '0' : (string)$mtime;
	}

	private function versioned(string $url, string $version): string {
		return $url . '?v=' . rawurlencode($version);
	}

	private function versionText(mixed $value): string {
		$text = is_scalar($value) ? trim((string)$value) : '';

		if ($text === '' || preg_match('/\A[A-Za-z0-9._-]+\z/', $text) !== 1) {
			return '0';
		}

		return $text;
	}

	private function readJson(string $name): array {
		$path = DIR_EXTENSION . 'ocn_theme_ai_simple/' . $name;

		if (!is_file($path)) {
			return [];
		}

		$raw = file_get_contents($path);

		if (!is_string($raw)) {
			return [];
		}

		$data = json_decode($raw, true);

		return is_array($data) ? $data : [];
	}
}
